
public class InvalidIFSCCodeException extends Exception {
	
	//Fill code
	public InvalidIFSCCodeException(String message ){
	    super (message);
	}
}
