public class Department
{
    private int did;
    private String dname;
    public int getDid()
    {
        return did;
    }
    public String getDname()
    {
        return dname;
    }
    public void setDid(int d)
    {
        did=d;
    }
    public void setDname(String name)
    {
        dname=name;
    }
}