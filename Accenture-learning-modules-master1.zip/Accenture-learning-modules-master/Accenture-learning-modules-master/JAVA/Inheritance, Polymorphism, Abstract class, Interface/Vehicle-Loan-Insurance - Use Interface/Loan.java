public interface Loan{
    public abstract double issueLoan();
}