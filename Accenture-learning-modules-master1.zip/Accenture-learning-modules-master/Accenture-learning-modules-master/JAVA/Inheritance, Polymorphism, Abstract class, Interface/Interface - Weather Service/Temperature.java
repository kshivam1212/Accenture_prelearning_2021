public interface Temperature{
    public float temp[]={45,29.6F,34,32};
}