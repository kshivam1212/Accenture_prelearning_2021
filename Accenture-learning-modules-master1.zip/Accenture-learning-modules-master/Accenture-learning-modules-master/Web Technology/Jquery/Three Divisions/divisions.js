//WRITE YOUR jQUERY CODE HERE
$('#button1').click(function(){
    $("div[name$='DAIntelligence']").css( "background", "yellow" );
    $("div[name$='ASI_Intelligence']").css( "background", "yellow" );
});